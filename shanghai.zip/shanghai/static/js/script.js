$(function () {

    //侧栏列表
    (function () {
        // var asideControl = $(".aside-list-link");
        // var asideSub = $(".aside-sublist");
        // asideControl.click(function () {
        //     var $this = $(this);
        //     var $thisSub = $this.siblings(".aside-sublist");

        //     asideControl.removeClass("act");
        //     $this.addClass("act");

        //     $thisSub.slideToggle();
        //     asideSub.not($thisSub).slideUp();
        // });
        $(".aside-list-link").click(function(){
            var $this = $(this);
            $this.parent().find(".aside-sublist").slideToggle(300);
            $this.parent().siblings().find(".aside-sublist").slideUp();
            
            $this.parent().find(".aside-list-link").toggleClass("act");
            $this.parent().siblings().find(".aside-list-link").removeClass("act");
        })

    })();
    
    //小屏产品中心折叠按钮
    var data = $(document.body).width();
    if (data < 992) {
        (function () {
            $(".s-drop-btn").click(function () {
                $(this).toggleClass("act");
                $(".s-drop-list").slideToggle(400);
            });
        })();
    }
    else {
    }

    //pc导航
    $(".nav-ul li").hover(function () {
        $(this).has("ul").children("ul").stop(true, true).slideToggle(500);
    },
    function () {
        $(this).has("ul").children("ul").stop(true).slideUp(500);
    });

    //$(".nav_a2").hover(function () {
    //    $('.nav_a2').removeClass("on");
    //    $(this).addClass("on");
    //})

    // 导航高亮
    function hrefA(){
		var href = location.href;
        $(".nav_a").each(function(index, el) {
            var $this = $(this);
            if ( href.indexOf( $this.attr("href").split(".")[0] ) >= 0 ){
                $this.parent().addClass('active');
            }
        })
        $(".sjnav ul a").each(function(index, el) {
            var $this = $(this);

            if ( href.indexOf( $this.attr("href").split(".")[0] ) >= 0 ){
                $this.parents('li').addClass('active');
            }
        })
        if( href.indexOf("index") < 1  &&  href.indexOf("asp") < 1 &&  href.indexOf("php") < 1 &&  href.indexOf("html") < 1 ){
        	$(".nav_a").addClass('active');
        	$(".sjnav ul li:nth-child(1)").addClass('active');
        }
	}
    hrefA();
  



    //手机导航
    $(".icon-menu").click(function () {
        $(this).toggleClass("click");
        $(".sjnav").slideToggle();
        $(".sjnav").toggleClass("click");
        $(".mask").fadeToggle();
        // var iphonenav = $(".sjnav").find("li").length;
        // if ($(".sjnav").hasClass("sjnavhide")) {
        //     $(".sjnav").animate({
        //         "height": (iphonenav * 45) + "px"
        //     }, 600);
        //     $(".sjnav").removeClass("sjnavhide");
        // } else {
        //     $(".sjnav").animate({
        //         "height": "0px"
        //     }, 600);
        //     $(".sjnav").addClass("sjnavhide");
        // }
    })

    //$(window).scroll(function () {
    //    if ($(window).scrollTop() > 1) {
    //        $('header').addClass('act');
    //    } else {
    //        $('header').removeClass('act');
    //    }
    //})

});

    // 视频获取视频url 有设置视频
    var video_urll = $('.b_video source').attr('src');
    if (video_urll != undefined && video_urll.length > 4) {
        $('.video_icon').css({
            display: 'block'
        });
        $('.h_video').mouseover(function () {
            $('.video_icon').css({
                transform: 'rotate(120deg)',
                transition: 'all 0.5s',
                'box-shadow': 'rgba(255, 255, 255, 0.8) 0px 2px 10px 2px',
                cursor: 'initial'
            });
        });
        $('.h_video').mouseout(function () {
            $('.video_icon').css({
                transform: 'rotate(-0deg)',
                transition: 'all 0.5s',
                'box-shadow': 'rgba(255, 255, 255, 0) 0px 2px 10px 2px'
            });
        });
        $('.h_video').on('click',
            function () {
                $('.b_video .g_video').css({
                    width: '700px',
                    transition: 'all 0.5s'
                });

                $('.b_video').css({
                    "opacity": '1',
                    "z-index": '9999'
                })
                $('.g_video video').trigger('play');
            });
        $('body').on('click',
            function (t) {
                if (t.target.className === 'video_btn') {
                    $('.g_video video').trigger('pause');
                    $('.b_video .g_video').css({
                        width: '100px',
                        transition: 'all 0.5s'
                    });
                    setTimeout(function () {
                        $('.b_video').css({
                            "opacity": '0',
                            "z-index": '-1'
                        })
                    },
                        400);
                }
            });
    } else {
        $('.h_video').addClass('baguetteBoxTwo gallery')
    }