
	$(".backwechat").click(function(){
			 wx.miniProgram.reLaunch({url: '/card/pages/index/index'})
	 });