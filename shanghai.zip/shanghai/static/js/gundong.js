function gundong() {

    //banner轮播图
    var mybenner = new Swiper('.swiper-benner', {
        //direction: 'vertical' ,   // 竖向切换
        autoHeight: true,           //高度随内容变化
        speed: 1000,                //切换速度
        //effect: 'fade',             //切换效果
        roundLengths : true, 
        autoplay: {                 //自动播放
            delay: 3000,
            stopOnLastSlide: false,
            disableOnInteraction: true,
        },
        // 分页器
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        // 前进后退按钮
        navigation: {
            nextEl: '.next-banner',
            prevEl: '.prev-banner',
        },
    })

    var mySwiper = new Swiper('.swiper-product', {
        slidesPerColumn:2,    //行数
        slidesPerColumnFill : 'row',  //排序
        slidesPerView: 3,       //张数
        spaceBetween: 15,       //间距
        speed: 1000,            //切换速度
        autoplay: {
            delay:5000,
            stopOnLastSlide: false,
            disableOnInteraction: true,
        },  
        // 前进后退按钮
        navigation: {
            nextEl: '.next-product',
            prevEl: '.prev-product',
        },
        breakpoints: {
            991: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            767: {
                slidesPerView: 1,
                spaceBetween: 10,
            },
        }
    })

    var mySwiper2 = new Swiper('.swiper-product2', {
        slidesPerView: 3,       //张数
        spaceBetween: 15,       //间距
        speed: 1000,            //切换速度
        autoplay: {
            delay:5000,
            stopOnLastSlide: false,
            disableOnInteraction: true,
        },  
        // 前进后退按钮
        navigation: {
            nextEl: '.next-product',
            prevEl: '.prev-product',
        },
        breakpoints: {
            991: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            767: {
                slidesPerView: 1,
                spaceBetween: 10,
            },
        }
    })

    var galleryThumbs = new Swiper('.gallery-thumbs', {
        spaceBetween: 5,
        slidesPerView: 5,
        speed: 1000,            
        freeMode: true,
        // loop: true,
        //loopedSlides: 5, //looped slides should be the same
        watchSlidesVisibility: true,
        watchSlidesProgress: true,
        autoplay: {                 
            delay: 5000,
            stopOnLastSlide: false,
            disableOnInteraction: true,
        },
    });
    var galleryTop = new Swiper('.gallery-top', {
        spaceBetween: 10,
        //loop:true,
        //loopedSlides:5, //looped slides should be the same
        speed: 1000,            
        navigation: {
            nextEl: '.next-thumbs',
            prevEl: '.prev-thumbs',
        },
        thumbs: {
            swiper: galleryThumbs,
        },
        autoplay: {                
            delay: 5000,
            stopOnLastSlide: false,
            disableOnInteraction: true,
            },
    });

    var mybox3 = new Swiper('.swiper-box3', {
        slidesPerView:3,       
        spaceBetween: 50,      
        speed: 1000,            
        autoplay: {
            delay: 5000,
            stopOnLastSlide: false,
            disableOnInteraction: true,
        },            
        navigation: {
            nextEl: '.next-box3',
            prevEl: '.prev-box3',
        },
        breakpoints: {
            991: {
                slidesPerView:2,
                spaceBetween: 10,
            },
            767: {
                slidesPerView: 1,
                spaceBetween: 5,
            },
        }
    })

    var myBox5 = new Swiper('.swiper-box5', {
        slidesPerColumnFill : 'row',  //鎺掑簭
        slidesPerColumn:2,    //琛屾暟
        slidesPerView: 4,       //寮犳暟
        spaceBetween: 10,     //闂磋窛
        speed: 1000,            //鍒囨崲閫熷害
        autoplay: {
            delay: 5000,
            stopOnLastSlide: false,
            disableOnInteraction: true,
        },  
        breakpoints: {
            991: {
                slidesPerView:3,
            },
            767: {
                slidesPerView: 2,
            },
        }
    })

}
gundong();